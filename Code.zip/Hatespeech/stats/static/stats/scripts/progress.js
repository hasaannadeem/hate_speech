const circulars = document.getElementsByClassName('circular');
const config = { attributes: true };

function setProgress(circular) {
    let progressBar = circular.querySelector('.progress');
    let bar_text = circular.querySelector('.bar_text');
    let value = circular.getAttribute('data-value');
    let radius = progressBar.r.baseVal.value;
    let circum = Math.round(2 * radius * Math.PI);
    let newValue = circum - (value/100) * circum;     

    bar_text.innerText = value + '%';        
    progressBar.style.strokeDasharray = circum;
    progressBar.style.strokeDashoffset = newValue;
}

const callback = function(mutationsList, observer) {
    for(const mutation of mutationsList) {
        if (mutation.type === 'attributes') {
            let circular =  mutation.target;
            setProgress(circular);
        }
    }
};

// Create an observer instance linked to the callback function
const observer = new MutationObserver(callback);

// Start observing the target node for configured mutations
for (var i = 0; i < circulars.length; i++){
    observer.observe(circulars[i], config);
    setProgress(circulars[i]); // for first time use
}