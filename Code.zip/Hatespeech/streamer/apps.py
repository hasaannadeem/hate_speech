from django.apps import AppConfig
from . import twitter_stream

class StreamerConfig(AppConfig):
    name = 'streamer'
    
    def ready(self):
        twitter_stream.start_stream()