import pymongo

class MongoDB():
    def __init__(self, host, port):
        self.client = pymongo.MongoClient(host=host, port=port)

    def use_db(self, dbname):
        self.db = self.client[dbname]
    
    def use_col(self, collection):
        self.col = self.db[collection]        

    def list_dbs(self):
        return self.client.list_database_names()
    
    def check_db(self, dbname):
        dblist = self.list_dbs()
        return True if dbname in dblist else False

    def list_col(self):
        return self.db.list_collection_names()
    
    def check_col(self, colname):
        collist = self.list_col()
        return True if colname in collist else False

    def insert_one(self, data):
        return self.col.insert_one(data)
    
    def insert_many(self, doc):
        return self.col.insert_many(doc)

    def find(self, query=None, toGet=None):
        return self.col.find(query, toGet)

    def find_one(self, query=None, toGet=None):
        return self.col.find_one(query, toGet)

    def sort(self, fieldname, direction=1):
        return self.find().sort(fieldname, direction)

    def update_one(self, query, newDoc):
        return self.col.update_one(query, {"$set": newDoc})
    
    def update_many(self, query, newDoc):
        return self.col.update_many(query, {"$set": newDoc})

    def delete_one(self, query):
        return self.col.delete_one(query)
    
    def delete_many(self, query={}):
        return self.col.delete_many(query)

    def delete_all(self):
        return self.col.delete_many({})
    
    def delete_col(self, colname=None):
        if colname is None:
            return self.col.drop()
        col = self.db[colname]
        return col.drop()

    def count_all(self, query=None, option=None):
        return self.col.count_documents(query, option)