consumer_key = "qTKDaLqezL7gX5OoFMNc9972a"
consumer_secret = "kKYJVMncQrO6Msb27uy2BNPq4DKYl6Sm7J8DthgaG2K0H3ty6D"
access_token = "1091706470536806403-YFlSkV7fc6SLShABmYaLkpEonJr3RB"
access_token_secret = "j7wL2VJzCIpVpHLQfGXPdarsojmLsgNhTlYy1sGvfNIrV"

host = "localhost"
port = 27017
db = "hatespeech"