import tweepy
import json
from . import keys
from .db import MongoDB
import datetime
import re

auth = tweepy.OAuthHandler(keys.consumer_key, keys.consumer_secret)
auth.set_access_token(keys.access_token, keys.access_token_secret)
api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True)

#creating a listener
class Listener(tweepy.StreamListener):

    def __init__(self, host, port, db_name, col_name):
        tweepy.StreamListener.__init__(self)
        self.client = MongoDB(host, port)
        self.client.use_db(db_name)
        self.client.use_col(col_name)

    def _status_to_json(self, status):
        tweet = re.sub('[^\u0621-\u06D2 ]', '', str(status.text))
        data = {
            'user_id': status.id,
            'name': status.user.name,
            'tweet': tweet,
            'date': str(status.created_at.date()),
            'time': str(status.created_at.time()),
            'has_hate': False,
            'has_religious': False,
            'has_racism': False,
            'has_other': False,
        }
        return data

    def on_status(self, status):
        if status.retweeted:
            return True
        data = self._status_to_json(status)
        self.client.insert_one(data)
        return True
    
    def on_error(self, status_code):
        if status_code == 402:
            return False

listener = Listener(host=keys.host, port=keys.port, db_name=keys.db, col_name="data")
stream = tweepy.streaming.Stream(
        auth=api.auth,
        listener=listener,
        wait_on_rate_limit=True,
        wait_on_rate_limit_notify=True
    )

def start_stream():
    stream.sample(languages=['ur'], is_async=True)