# Hatespeech
Hatespeech detector for twitter fyp project
